<!DOCTYPE html>
<html>
    <head>
      <link rel="stylesheet" href="background_styles.css">
      <link rel="stylesheet" href="style.css">
      <script src="script.js" defer></script>
      <title>Basic PHP</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta viewport>
    </head>
    <body>
      <nav class="navbar">
        <div class="brand-title">MycataLog!</div>
        <a href="#" class="toggle-button">
          <span class="bar"></span>
          <span class="bar"></span>
          <span class="bar"></span>
        </a>
        <div class="navbar-links">
          <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
</ul>
<center>
<div class="dropdown">
    <button class="dropbtn" style="height: 100%;">Dropdown
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="#">Link 1</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </div>
  </div> 
  </center>
</div>
      </nav>
      <div class="content">
      <img src="img/istockphoto-489181824-170667a.jpg" width="70%" height="150px" style="position: relative;float:right;">
      <div class="sidebar"width="20%">
    <ul>
   <li><a href="#">สินค้าทั่วไป</a></li>
  <li><a href="#">อาหารและเครื่องดื่ม</a></li>
  <li><a href="#">เครื่องใช้ไฟฟ้า</a></li>
  <li><a href="#">เครื่องมือสื่อสาร</a></li>
    </ul>
      </div>
      </div>
      <h1 style="font-size: 36px;font-weight: 800;text-align: center;">สินค้า</h1>
    </body>
<script src="script.js"></script>
</html>